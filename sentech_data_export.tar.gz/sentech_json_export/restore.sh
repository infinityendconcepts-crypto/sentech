#!/bin/bash
set -e
DB_NAME="sentech_db"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "=== Restoring Sentech Database ==="
echo "This will DROP existing data in '$DB_NAME' and replace it."
read -p "Continue? (y/n): " confirm
if [ "$confirm" != "y" ]; then echo "Cancelled."; exit 0; fi

# Drop existing DB
mongosh --quiet --eval "db.getSiblingDB('$DB_NAME').dropDatabase()"
echo "Cleared existing database"

# Import each collection
for file in "$SCRIPT_DIR"/*.json; do
    col=$(basename "$file" .json)
    if [ "$col" = "restore" ]; then continue; fi
    count=$(python3 -c "import json; d=json.load(open('$file')); print(len(d))")
    if [ "$count" = "0" ]; then
        echo "  Skipping $col (empty)"
        continue
    fi
    mongoimport --db "$DB_NAME" --collection "$col" --jsonArray --file "$file" --quiet
    echo "  Imported $col ($count docs)"
done

echo ""
echo "=== Migration Complete ==="
mongosh --quiet --eval "
db = db.getSiblingDB('$DB_NAME');
var total = 0;
db.getCollectionNames().forEach(function(c) {
    var n = db[c].countDocuments({});
    total += n;
    print('  ' + c + ': ' + n + ' docs');
});
print('  Total: ' + total + ' documents');
"
echo ""
echo "Now restart your backend:"
echo "  sudo systemctl restart sentech"
